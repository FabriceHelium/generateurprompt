export const supernatural = {
  category: 'Supernatural',
  creatures: [
    'Incubus',
    'Succubus',
    'Shadow Person',
    'Djinn',
    'Skinwalker',
    'Demonic Entity'
  ]
};