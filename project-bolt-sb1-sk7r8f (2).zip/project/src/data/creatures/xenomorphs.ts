export const xenomorphs = {
  category: 'Xenomorphs',
  creatures: [
    'Facehugger',
    'Chestburster',
    'Warrior Xenomorph',
    'Queen Xenomorph',
    'Predalien',
    'Neomorph'
  ]
};