export const humanoids = {
  category: 'Humanoids',
  creatures: [
    'Sasquatch (Bigfoot)',
    'Yeti (Abominable Snowman)',
    'Nordic Aliens (Tall Blonds)',
    'Grey Aliens (Little Greys)',
    'Reptilian Humanoids',
    'Ummites'
  ]
};