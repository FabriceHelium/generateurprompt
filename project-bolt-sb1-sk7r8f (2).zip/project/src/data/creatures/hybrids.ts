export const hybrids = {
  category: 'Hybrids',
  creatures: [
    'Human-Alien Hybrid',
    'Animal-Alien Hybrid',
    'Xenomorph Runner',
    'Predator-Alien Hybrid',
    'Biomechanical Hybrid'
  ]
};