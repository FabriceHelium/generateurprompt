export const cryptids = {
  category: 'Cryptids',
  creatures: [
    'Chupacabra',
    'Mothman',
    'Jersey Devil',
    'Loch Ness Monster',
    'Kraken',
    'Wendigo'
  ]
};