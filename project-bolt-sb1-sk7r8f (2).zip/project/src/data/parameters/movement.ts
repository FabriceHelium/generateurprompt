export const movements = {
  category: 'Mode Mouvement',
  options: [
    'Normal Fluide',
    'Performance Dynamique',
    'Ralenti Dramatique',
    'Accéléré Frénétique',
    'Stop Motion',
    'Flux Continu',
    'Saccadé Stylisé',
    'Chorégraphié'
  ]
};