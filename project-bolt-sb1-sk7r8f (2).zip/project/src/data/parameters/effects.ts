export const effects = {
  category: 'Effets Spéciaux',
  options: [
    'Venom Noir',
    'Venom Coloré',
    'Harley Quinn',
    'Joker Chaos',
    'Batman Nocturne',
    'Iron Man Tech',
    'Métamorphose Féline',
    'Embrace Supernatural',
    'Symbiote Fusion',
    'Coups Méchants',
    'Écrasement Slime',
    'Transformation Héroïque'
  ]
};