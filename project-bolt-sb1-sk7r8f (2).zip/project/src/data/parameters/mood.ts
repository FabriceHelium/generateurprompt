export const moods = {
  category: 'Ambiance',
  options: [
    'Terrifiante',
    'Apaisante',
    'Mystérieuse',
    'Fascinante',
    'Inquiétante',
    'Surnaturelle',
    'Festive',
    'Chaotique',
    'Mélancolique',
    'Onirique'
  ]
};