export const aspectRatios = {
  category: 'Format Vidéo',
  options: [
    '16:9 (Paysage Cinéma)',
    '9:16 (Portrait Mobile)',
    '1:1 (Carré Social)',
    '4:3 (Rétro TV)',
    '21:9 (Ultra-Large)',
    '2.39:1 (Scope)',
    '1.85:1 (Standard DCP)',
    'IMAX (1.43:1)'
  ]
};