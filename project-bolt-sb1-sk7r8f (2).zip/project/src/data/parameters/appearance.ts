export const appearances = {
  category: 'Type d\'Apparition',
  options: [
    'Fantôme',
    'Créature Mythologique',
    'Animal Sauvage',
    'Phénomène Scientifique',
    'Manifestation Divine',
    'Anomalie Temporelle',
    'Projection Astrale',
    'Entité Cosmique'
  ]
};