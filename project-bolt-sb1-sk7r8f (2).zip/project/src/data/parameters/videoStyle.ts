export const videoStyles = {
  category: 'Style Visuel',
  options: [
    'Anime Japonais',
    'Animation 3D Photoréaliste',
    'Stop-Motion Argile',
    'Papier Découpé Artistique',
    'Rétro 8-bit',
    'Cinématographique 4K',
    'Dessin Animé Classique',
    'Art Numérique Moderne',
    'Aquarelle Animée',
    'Pixel Art'
  ]
};